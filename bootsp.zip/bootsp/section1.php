<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Section1</title>
	<link rel="stylesheet" href="">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
  <style type="text/css">
#s1{
    background: url(img/slider-image.png);
    padding: 5%;
    background-repeat: no-repeat;
    background-size: 100% 100%;
}
#s1 hr{
   border-color: white;
}
#s1 p{
    color: white;
    font-size: 12px;
}
.b1{
    width: 140px;
    height: 50px;
    background-color: transparent;
    border: 1px solid white;
    color: white;
    font-size: 13px;
}
.b2{
    width: 140px;
    height: 50px;
    background-color: #fdce16;
    border: 1px solid #fdce16;
    color: black;
    font-size: 13px;
}
#s1 img{
    display: block;
    margin: auto;
}

  </style>
</head>
<body>
	 <section id="s1">
       <div class="container-fluid">
           <div class="row">
               <div class="offset-lg-3 col-lg-6">
                   <img src="img/foco.png" class="img-fluid">
               </div>
           </div>
           <div class="row">
               <div class="offset-lg-3 col-lg-1">
                   <hr>
               </div>
               <div class="col-lg-3">
                   <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse, omnis!</p>
               </div>
               <div class="col-lg-5">
                   <button class="b1">CONHECA</button>
                   <button class="b2">ORCAHMENTO</button>
               </div>
           </div>
       </div>
   </section>
	
</body>
</html>