<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Section3</title>
	<link rel="stylesheet" href="">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
  <style type="text/css">
    <!-- section 3 part here part css -->
    
#s4{
   background-image: url(../img/s4bg.jpg);
    padding: 5%;
    background-repeat: no-repeat;
    background-size: 100% 100%; 
}
#s4 h3,#s4 h5{
    color: gainsboro;
}
#s4 p{
    color: gray;
    font-size: 13px;
}
#s4 hr{
    border-color: gray;
}
.tholder{
    padding: 3% 15px;
}
.nf{
    color: white;
    text-align: right;
}
.carousel-item{
    padding: 4%;
}
style>
</head>
<body>
	 <section id="s4">
       <div class="container-fluid">
           <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <div class="row">
          <div class="offset-lg-1 col-lg-5 tholder">
              <h3>MARKETING PARA PSYCOLOGY</h3>
              <H5>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore, doloribus.</H5>
              <P>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate qui perferendis reprehenderit assumenda, quidem distinctio, molestias alias, saepe voluptatum ut ipsa id non libero delectus culpa ratione earum. Dolor maiores sed, repudiandae soluta possimus neque adipisci amet aliquid nam quia assumenda, quidem distinctio, molestias alias, saepe voluptatum ut ipsa id non libero delectus culpa ratione earum. Dolor maiores sed, repudiandae soluta possimus neque adipisci amet aliquid nam quia.</P>
              <hr>
              <span class="nf">95%</span>
              <div class="nf">95%</div>
              <div class="progress">
  <div class="progress-bar" role="progressbar" style="width: 75%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">75%</div>
            </div>
          </div>
          <div class="col-lg-5">
              <img src="img/project-image.png" class="img-fluid">
          </div>
      </div>
    </div>
    <div class="carousel-item">
      <div class="row">
          <div class="offset-lg-1 col-lg-5 tholder">
              <h3>MARKETING PARA PSYCOLOGY</h3>
              <H5>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore, doloribus.</H5>
              <P>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate qui perferendis reprehenderit assumenda, quidem distinctio, molestias alias, saepe voluptatum ut ipsa id non libero delectus culpa ratione earum. Dolor maiores sed, repudiandae soluta possimus neque adipisci amet aliquid nam quia assumenda, quidem distinctio, molestias alias, saepe voluptatum ut ipsa id non libero delectus culpa ratione earum. Dolor maiores sed, repudiandae soluta possimus neque adipisci amet aliquid nam quia.</P>
              <hr>
          </div>
          <div class="col-lg-5">
              <img src="img/project-image.png" class="img-fluid">
          </div>
      </div>
    </div>
    
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <i class="far fa-arrow-alt-circle-left fa-2x"></i>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <i class="far fa-arrow-alt-circle-right fa-2x"></i>
  </a>
</div>
       </div>
   </section>
	
</body>
</html>