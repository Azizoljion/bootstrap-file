<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Index</title>
	<link rel="stylesheet" href="">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
  <style type="text/css">
    <!-- header part css -->
    .navbar-light .navbar-nav .nav-link{
    padding: 32px 8px;
    font-size: 14px;
    color: black;
    
}
.navbar-light .navbar-nav .nav-link:focus, .navbar-light .navbar-nav .nav-link:hover{
    color: #fdce16;
    border-top: 2px solid #fdce16;
    padding: 30px 8px;
}
.navbar{
    padding: 0px 32px;
}
/*.nav-link:hover{
    color: #fdce16!important;
}*/
.actionbar{
    border-bottom: 1px solid #e7e7e7;
    font-size: 14px;
}
.cl{
    border-left: 1px solid #e7e7e7;
    border-right: 1px solid #e7e7e7;
}
.actionbar a{
    border-right: 1px solid #e7e7e7;
    padding: 0px 10px;
}
.cl2{
    padding-left: 0px;
}
.fa-envelope{
    color: #fdce16;
}
.fa-phone{
    color: #fdce16;
    transform: rotate(90deg);
}
  </style>
</head>
<body>
	 <header>
    <div class="actionbar d-none d-lg-block">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-xl-3 text-right">
                   <i class="far fa-envelope" style="color: #fdce16;"></i> azizolhaque77@gmail.com
                </div>
                <div class="col-lg-5 col-xl-7 cl">
                   <i class="fas fa-phone"></i> +88001679428948
                </div>
                <div class="col-lg-3 col-xl-2 cl2">
                    <a href="https://twitter.com/AzizolJion"><i class="fab fa-twitter" style="color: #fdce16;"></i></a>
                    <a href="https://www.facebook.com/jion.mehmud"><i class="fab fa-facebook-f" style="color: #fdce16;"></i></a>
                    <a href="https://www.linkedin.com/in/jion-mahmud-b0890617b/"><i class="fab fa-linkedin-in" style="color: #fdce16;"></i></a>
                    <a href="https://www.behance.net/azizoljion"><i class="fab fa-behance" style="color: #fdce16;"></i></a>
                </div>
            </div>
            
        </div>  
    </div>
     <!--navbar starts-->
      <div class="container">
       <nav class="navbar navbar-expand-lg navbar-light">
  <a class="navbar-brand" href="#"><img src="img/logo.png"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Sobre Nos</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Projetos</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Processos</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Criacoes</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Contact</a>
      </li>
    </ul>
  </div>
</nav>
</div>
   </header>
	
</body>
</html>