<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Footer</title>
	<link rel="stylesheet" href="">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
  <style type="text/css">
    <!-- footer part here part css -->
#s7{
    padding: 2% 10%;
}
#s7 h1{
    text-align: center;
}
#s7 img{
    display: block;
    margin: auto;
}
#s7 .border{
    border: 1px solid #cacaca;
    padding: 20px;
}
.form-control{
    border-radius: 0px;
}
#s7 form button{
    margin-top: -20px;
    float: right;
    margin-right: 20px;
}
  </style>
</head>
<body>
	   <section id="s7">
       <h1>FALE CONOSCO</h1>
       <img src="img/newline.png" class="img-fluid">
       <br>
       <div class="container-fluid">
           <div class="row">
               <div class="col-lg-7">
                   <form>
                    <div class="border">
                        <div class="form-group">
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
  </div>
  <div class="form-group">
    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
  </div>
  <div class="form-group">
    <textarea class="form-control" rows="4" placeholder="mensagem"></textarea>
  </div>                    
</div>
     <button type="submit" class="btn btn-primary">Submit</button>                  
 </form>
 </div>
 <div class="col-lg-5">
     <b>Tel :</b>
     <span>+12345678</span>
 </div>
</div>
</div>
       
   </section> 
	
</body>
</html>