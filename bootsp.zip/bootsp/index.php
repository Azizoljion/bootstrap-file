<!-- include header here -->
<?php include('header.php'); ?>
<!-- include section1 here -->
<?php include('section1.php') ?>
<!-- include section2 here -->
<?php include('section2.php') ?>
<!-- include footer here -->
<?php include('footer.php') ?>