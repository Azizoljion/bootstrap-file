<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Section2</title>
	<link rel="stylesheet" href="">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
  <style type="text/css">
    <!-- section 2 part here part css -->
#s2{
    padding: 5% 10%;
}
.box{
    height: 250px;
    width: 100%;
    border: 1px solid grey;
    margin: 40px auto;
    text-align: center;
    
}
.icon-box{
    height: 60px;
    width: 60px;
    border: 1px solid grey;
    margin: auto;
    margin-top: -30px;
    transform: rotate(45deg);
    background-color: white;
}
.icon-box:hover{
    background-color: #fdce16;
    border: 1px solid #fdce16;
}
.icon-box img{
    height: 16px;
    display: block;
    margin: 22px auto;
    transform: rotate(-45deg);
}
.box p{
    font-size: 13px;
    color: gray;
}
.box hr{
    width: 50px;
    margin: 5px auto;
}
  </style>
</head>
<body>
	<br>
	 <section id="s2">
       <div class="container-fluid">
           <div class="row">
               <div class="col-md-6 col-lg-3">
                   <div class="box">
                       <div class="icon-box">
                           <img src="img/Bulb.png">
                       </div>
                       <br>
                       <h5>Web</h5>
                       <hr>
                       <hr>
                       <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut corporis rem dicta.</p>
                   </div>
               </div>
               <div class="col-md-6 col-lg-3">
                   <div class="box">
                       <div class="icon-box">
                           <img src="img/Bulb.png">
                       </div>
                        <br><h5>Design</h5>
                       <hr>
                       <hr>
                       <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut corporis rem dicta.</p>
                   </div>
               </div>
               <div class="col-md-6 col-lg-3">
                   <div class="box">
                       <div class="icon-box">
                           <img src="img/Bulb.png">
                       </div>
                        <br><h5>Trafego</h5>
                       <hr>
                       <hr>
                       <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut corporis rem dicta.</p>
                   </div>
               </div>
               <div class="col-md-6 col-lg-3">
                   <div class="box">
                       <div class="icon-box">
                           <img src="img/Bulb.png">
                       </div>
                        <br><h5>Suporte</h5>
                       <hr>
                       <hr>
                       <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut corporis rem dicta.</p>
                   </div>
               </div>
           </div>
       </div>
   </section>
	
</body>
</html>